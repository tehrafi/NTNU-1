package interfaces;

public interface Named {
	void setGivenName(String name);
	String getGivenName();
	void setFamilyName(String name);
	String getFamilyName();
	void setFullName(String name);
	String getFullName();
}
