<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:exercise="platform:/plugin/no.hal.learning.exercise.model/model/exercise.ecore" xmlns:jdt="platform:/plugin/no.hal.learning.exercise.jdt/model/jdt-exercise.ecore" xmlns:junit="platform:/plugin/no.hal.learning.exercise.junit/model/junit-exercise.ecore" xmlns:workbench="platform:/plugin/no.hal.learning.exercise.workbench/model/workbench-exercise.ecore">
  <exercise:Exercise>
    <parts xsi:type="exercise:ExercisePart" title="Named interface">
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Write source code for the Named interface."/>
        <a xsi:type="jdt:JdtSourceEditAnswer" className="interfaces.Named"/>
      </tasks>
    </parts>
    <parts xsi:type="exercise:ExercisePart" title="Person1 and Person2">
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Write source code for the Person1 class."/>
        <a xsi:type="jdt:JdtSourceEditAnswer" className="interfaces.Person1"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Write source code for the Person2 class."/>
        <a xsi:type="jdt:JdtSourceEditAnswer" className="interfaces.Person2"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Test the Person1 class, by running its main method."/>
        <a xsi:type="jdt:JdtLaunchAnswer" className="interfaces.Person1"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Test the Person2 class, by running its main method."/>
        <a xsi:type="jdt:JdtLaunchAnswer" className="interfaces.Person2"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Run the Person1Test JUnit test."/>
        <a xsi:type="junit:JunitTestAnswer" testRunName="interfaces.Person1Test"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Run the Person2Test JUnit test."/>
        <a xsi:type="junit:JunitTestAnswer" testRunName="interfaces.Person2Test"/>
      </tasks>
    </parts>
    <parts xsi:type="exercise:ExercisePart" title="NamedComparator">
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Write source code for the NamedComparator class."/>
        <a xsi:type="jdt:JdtSourceEditAnswer" className="interfaces.NamedComparator"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Test the NamedComparator class, by running its main method."/>
        <a xsi:type="jdt:JdtLaunchAnswer" className="interfaces.NamedComparator"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Run the NamedComparatorTest JUnit test."/>
        <a xsi:type="junit:JunitTestAnswer" testRunName="interfaces.NamedComparatorTest"/>
      </tasks>
    </parts>
    <parts xsi:type="exercise:ExercisePart" title="Tool usage">
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use breakpoints to debug the Person classes."/>
        <a xsi:type="workbench:DebugEventAnswer" elementId="interfaces.Person*" action="suspend.breakpoint"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use breakpoints to debug the NamedComparator class."/>
        <a xsi:type="workbench:DebugEventAnswer" elementId="interfaces.Named*" action="suspend.breakpoint"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use the debug command Step Over"/>
        <a xsi:type="workbench:CommandExecutionAnswer" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use the debug command Step Into"/>
        <a xsi:type="workbench:CommandExecutionAnswer" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
      </tasks>
      <tasks xsi:type="exercise:Task">
        <q xsi:type="exercise:StringQuestion" question="Use the Variables view"/>
        <a xsi:type="workbench:PartTaskAnswer" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
      </tasks>
    </parts>
  </exercise:Exercise>
  <exercise:ExerciseProposals exercise="/0">
    <proposals exercisePart="/0/@parts.0">
      <proposals xsi:type="jdt:JdtSourceEditProposal" question="/0/@parts.0/@tasks.0/@q" answer="/0/@parts.0/@tasks.0/@a">
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294441966" resourcePath="/ovinger/src/interfaces/Named.java" sizeMeasure="5" className="interfaces.Named">
          <edit xsi:type="exercise:StringEdit" storedString="package interfaces;&#xA;&#xA;public interface Named {&#xA;&#xA;}&#xA;"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294557504" resourcePath="/ovinger/src/interfaces/Named.java" sizeMeasure="9" errorCount="1" className="interfaces.Named">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;void setGivenName(String name)&#xA;&#x9;String getGivenName();&#xA;&#x9;void setFamilyName(String name);&#xA;&#x9;String getFamilyName();&#xA;&#x9;void setFullName(String name);" edit="/1/@proposals.0/@proposals.0/@attempts.0/@edit" start="46" end="-4"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="4" charStart="76" charEnd="77" severity="2" problemCategory="20" problemType="1610612976"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294560208" resourcePath="/ovinger/src/interfaces/Named.java" sizeMeasure="9" className="interfaces.Named">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString=";" edit="/1/@proposals.0/@proposals.0/@attempts.1/@edit" start="77" end="-119"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294753265" resourcePath="/ovinger/src/interfaces/Named.java" sizeMeasure="10" errorCount="2" className="interfaces.Named">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;String getFamilyName(" edit="/1/@proposals.0/@proposals.0/@attempts.2/@edit" start="194" end="-6"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="9" charStart="202" charEnd="217" severity="2" problemCategory="50" problemType="67109219"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294761347" resourcePath="/ovinger/src/interfaces/Named.java" sizeMeasure="10" className="interfaces.Named">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="ull" edit="/1/@proposals.0/@proposals.0/@attempts.3/@edit" start="206" end="-11"/>
        </attempts>
      </proposals>
    </proposals>
    <proposals exercisePart="/0/@parts.1">
      <proposals xsi:type="jdt:JdtSourceEditProposal" question="/0/@parts.1/@tasks.0/@q" answer="/0/@parts.1/@tasks.0/@a">
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294585381" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="35" className="interfaces.Person1">
          <edit xsi:type="exercise:StringEdit" storedString="package interfaces;&#xA;&#xA;public class Person1 implements Named {&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;}&#xA;"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294779323" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="46" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;&#xA;&#x9;String givenName;&#xA;&#x9;String familyName;&#xA;&#x9;&#xA;&#x9;public Person1 (String givenName, String familyName) {&#xA;&#x9;&#x9;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;this.givenName = name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return givenName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;this.familyName = name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return familyName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;" edit="/1/@proposals.1/@proposals.0/@attempts.0/@edit" start="61" end="-8"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294967241" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="47" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="setGivenName(givenName);&#xA;&#x9;&#x9;setFamilyName(familyName);&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;this.givenName = name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return givenName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;this.familyName = name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return familyName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;" edit="/1/@proposals.1/@proposals.0/@attempts.1/@edit" start="162" end="-105"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295584400" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="47" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" edit="/1/@proposals.1/@proposals.0/@attempts.2/@edit" start="861"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296469005" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="49" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.givenName = parts[0];&#xA;&#x9;&#x9;this.familyName = parts[1];&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return givenName + familyName" edit="/1/@proposals.1/@proposals.0/@attempts.3/@edit" start="757" end="-9"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519297567794" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="55" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;String l = &quot;Sander Lindberg&quot;;&#xA;&#x9;&#x9;String g[] = l.split(&quot; &quot;);&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;System.out.println(g[0])" edit="/1/@proposals.1/@proposals.0/@attempts.4/@edit" start="968" end="-9"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519297575815" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="55" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString=" + &quot;edee&quot;" edit="/1/@proposals.1/@proposals.0/@attempts.5/@edit" start="1099" end="-10"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519297581172" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="55" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="1" edit="/1/@proposals.1/@proposals.0/@attempts.6/@edit" start="1097" end="-20"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519297592770" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="55" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&quot;ff3&quot; + g[1]" edit="/1/@proposals.1/@proposals.0/@attempts.7/@edit" start="1095" end="-10"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519298285458" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="43" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="this.givenName = name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;return givenName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;this.familyName = name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;return familyName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;//String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.givenName = name.substring(0, name.indexOf(&quot; &quot;));//parts[0];&#xA;&#x9;&#x9;this.familyName = name.substring(name.indexOf(&quot; &quot;) + 1, name.length());&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;return givenName + familyName;&#xA;&#x9;}&#xA;&#x9;" edit="/1/@proposals.1/@proposals.0/@attempts.8/@edit" start="273" end="-4"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519298466101" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="43" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&quot; &quot;" edit="/1/@proposals.1/@proposals.0/@attempts.9/@edit" start="816" end="-23"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519298502208" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="45" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;/*this.givenName = name.substring(0, name.indexOf(&quot; &quot;));//parts[0];&#xA;&#x9;&#x9;this.familyName = name.substring(name.indexOf(&quot; &quot;) + 1, name.length());*/&#xA;&#x9;&#x9;this.givenName = parts[0];&#xA;&#x9;&#x9;this.familyName = parts[1]" edit="/1/@proposals.1/@proposals.0/@attempts.10/@edit" start="572" end="-94"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519298514066" resourcePath="/ovinger/src/interfaces/Person1.java" sizeMeasure="43" className="interfaces.Person1">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="t" edit="/1/@proposals.1/@proposals.0/@attempts.11/@edit" start="608" end="-148"/>
        </attempts>
      </proposals>
      <proposals xsi:type="jdt:JdtSourceEditProposal" question="/0/@parts.1/@tasks.1/@q" answer="/0/@parts.1/@tasks.1/@a">
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294599417" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="35" className="interfaces.Person2">
          <edit xsi:type="exercise:StringEdit" storedString="package interfaces;&#xA;&#xA;public class Person2 implements Named {&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;}&#xA;"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294773476" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="41" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;" edit="/1/@proposals.1/@proposals.1/@attempts.0/@edit" start="543" end="-8"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294938711" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="47" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;&#xA;&#x9;String fullName;&#xA;&#x9;&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = parts[0] + &quot; &quot; + parts[1];" edit="/1/@proposals.1/@proposals.1/@attempts.1/@edit" start="61" end="-106"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519294957161" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="47" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="setFullName(fullName);&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return null;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = parts[0] + &quot; &quot; + parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.fullName" edit="/1/@proposals.1/@proposals.1/@attempts.2/@edit" start="120" end="-9"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295274332" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="50" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="String givenName;&#xA;&#x9;&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;setFullName(fullName);&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.givenName = parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.givenName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.givenName = parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.familyName" edit="/1/@proposals.1/@proposals.1/@attempts.3/@edit" start="82" end="-289"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295288827" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="51" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="String familyName;&#xA;&#x9;&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;setFullName(fullName);&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.givenName = parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.givenName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.family" edit="/1/@proposals.1/@proposals.1/@attempts.4/@edit" start="101" end="-415"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295411907" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="59" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;@Override&#xA;&#x9;public String toString() {&#xA;&#x9;&#x9;return &quot;Given name: &quot; + givenName + &quot;\nFamily name: &quot; + familyName + &quot;\nFull name: &quot; + fullName;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Person2 p = new Person2(&quot;Sander Lindberg&quot;);&#xA;&#x9;&#x9;System.out.println(p);&#xA;&#x9;}" edit="/1/@proposals.1/@proposals.1/@attempts.5/@edit" start="1002" end="-4"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295437872" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="61" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;setGivenName(fullName);&#xA;&#x9;&#x9;setFamily" edit="/1/@proposals.1/@proposals.1/@attempts.6/@edit" start="183" end="-1098"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295718104" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="98" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="/*public class Person2 implements Named {&#xA;&#x9;&#xA;&#x9;String fullName;&#xA;&#x9;String givenName;&#xA;&#x9;String familyName;&#xA;&#x9;&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;setFullName(fullName);&#xA;&#x9;&#x9;setGivenName(fullName);&#xA;&#x9;&#x9;setFamilyName(fullName);&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.givenName = parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.givenName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.familyName = parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.familyName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = parts[0] + &quot; &quot; + parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.fullName;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public String toString() {&#xA;&#x9;&#x9;return &quot;Given name: &quot; + givenName + &quot;\nFamily name: &quot; + familyName + &quot;\nFull name: &quot; + fullName;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Person2 p = new Person2(&quot;Sander Lindberg&quot;);&#xA;&#x9;&#x9;System.out.println(p);&#xA;&#x9;}&#xA;}*/&#xA;public class Person2 implements Named{&#xA;&#x9;&#xA;&#x9;private String fullName;&#xA;&#x9;&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;this.fullName = fullName;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public void setGivenName(String givenName) {&#xA;&#x9;&#x9;this.fullName = givenName + &quot; &quot; + this.fullName.substring(this.fullName.indexOf(' ') + 1, fullName.length());&#xA;&#x9;}&#xA;&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;return this.fullName.substring(0, this.fullName.indexOf(' '));&#xA;&#x9;}&#xA;&#xA;&#x9;public void setFamilyName(String familyName) {&#xA;&#x9;&#x9;this.fullName = this.fullName.substring(0, this.fullName.indexOf(' ')) + &quot; &quot; + familyName;&#xA;&#x9;}&#xA;&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;return this.fullName.substring(this.fullName.indexOf(' ') + 1, fullName.length());&#xA;&#x9;}&#xA;&#xA;&#x9;public void setFullName(String fullName) {&#xA;&#x9;&#x9;this.fullName = fullName;&#xA;&#x9;}&#xA;&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;return this.fullName;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public String toString() {&#xA;&#x9;&#x9;return this.fullName;&#xA;&#x9;}&#xA;" edit="/1/@proposals.1/@proposals.1/@attempts.7/@edit" start="21" end="-4"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295753189" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="57" errorCount="6" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="public class Person2 implements Named {&#xA;&#x9;&#xA;&#x9;String fullName;&#xA;&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;setFullName(fullName);&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.givenName = parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.givenName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.familyName = parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.familyName;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = name.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = parts[0] + &quot; &quot; + parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.fullName;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public String toString() {&#xA;&#x9;&#x9;return &quot;Given name: &quot; + givenName + &quot;\nFamily name: &quot; + familyName + &quot;\nFull name: &quot; + fullName;&#xA;&#x9;}&#xA;&#x9;&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;Person2 p = new Person2(&quot;Sander Lindberg&quot;);&#xA;&#x9;&#x9;System.out.println(p);&#xA;&#x9;}" edit="/1/@proposals.1/@proposals.1/@attempts.8/@edit" start="21" end="-4"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="50" charStart="1059" charEnd="1069" severity="2" problemCategory="50" problemType="33554515"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295869374" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="56" errorCount="2" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;setFullName(fullName);&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;this.fullName = name + parts[1]; &#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;this.fullName = parts[0] + name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return parts[1]" edit="/1/@proposals.1/@proposals.1/@attempts.9/@edit" start="81" end="-547"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="49" charStart="1032" charEnd="1042" severity="2" problemCategory="50" problemType="33554515"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295888339" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="55" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="this.fullName = parts[0] + &quot; &quot; + parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.fullName;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public String toString() {&#xA;&#x9;&#x9;return &quot;Given name: &quot; + parts[0] + &quot;\nFamily name: &quot; + parts[1]" edit="/1/@proposals.1/@proposals.1/@attempts.10/@edit" start="746" end="-155"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296035794" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="60" errorCount="2" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#xA;&#x9;public Person2(String fullName) {&#xA;&#x9;&#x9;setFullName(fullName);&#xA;&#x9;&#x9;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;public void setGivenName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = name + parts[1]; &#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;return parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = parts[0] + name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;return parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = parts[0] + &quot; &quot; + parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return this.fullName;&#xA;&#x9;}&#xA;&#x9;@Override&#xA;&#x9;/*public String toString() {&#xA;&#x9;&#x9;return &quot;Given name: &quot; + parts[0] + &quot;\nFamily name: &quot; + parts[1] + &quot;\nFull name: &quot; + fullName;&#xA;&#x9;}*/&#xA;&#x9;&#xA;&#x9;/*public static void main(String[] args) {&#xA;&#x9;&#x9;Person2 p = new Person2(&quot;Sander Lindberg&quot;);&#xA;&#x9;&#x9;System.out.println(p);&#xA;&#x9;}*/" edit="/1/@proposals.1/@proposals.1/@attempts.11/@edit" start="82" end="-4"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="51" charStart="1084" charEnd="1092" severity="2" problemCategory="20" problemType="1610612976"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296040075" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="60" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#xA;" edit="/1/@proposals.1/@proposals.1/@attempts.12/@edit" start="1083" end="-256"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296069503" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="60" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="public static void main(String[] args) {&#xA;&#x9;&#x9;Person2 p = new Person2(&quot;Sander Lindberg&quot;);&#xA;&#x9;&#x9;System.out.println(p);&#xA;&#x9;}" edit="/1/@proposals.1/@proposals.1/@attempts.13/@edit" start="1218" end="-4"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296096217" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="60" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="n" edit="/1/@proposals.1/@proposals.1/@attempts.14/@edit" start="901" end="-425"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296173994" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="59" errorCount="2" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="this.fullName = name" edit="/1/@proposals.1/@proposals.1/@attempts.15/@edit" start="884" end="-365"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="42" charStart="900" charEnd="904" severity="2" problemCategory="20" problemType="1610612976"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296174890" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="59" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString=";" edit="/1/@proposals.1/@proposals.1/@attempts.16/@edit" start="904" end="-365"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296195041" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="59" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="this.fullName = fullName" edit="/1/@proposals.1/@proposals.1/@attempts.17/@edit" start="120" end="-1129"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296376822" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="61" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="/*String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = name + parts[1]; */&#xA;&#x9;&#x9;this.fullName = name + &quot; &quot; + this.fullName.substring(fullName.indexOf(&quot; &quot;) + 1, fullName.length());&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;return parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;/*String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;this.fullName = parts[0] + name;*/&#xA;&#x9;&#x9;this.fullName = this.fullName.substring(0, fullName.indexOf(&quot; &quot;)) + &quot; &quot;" edit="/1/@proposals.1/@proposals.1/@attempts.18/@edit" start="243" end="-638"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519296477141" resourcePath="/ovinger/src/interfaces/Person2.java" sizeMeasure="42" className="interfaces.Person2">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="this.fullName = name + &quot; &quot; + this.fullName.substring(fullName.indexOf(&quot; &quot;) + 1, fullName.length());&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getGivenName() {&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;return parts[0];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFamilyName(String name) {&#xA;&#x9;&#x9;this.fullName = this.fullName.substring(0, fullName.indexOf(&quot; &quot;)) + &quot; &quot; + name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFamilyName() {&#xA;&#x9;&#x9;String parts[] = this.fullName.split(&quot; &quot;);&#xA;&#x9;&#x9;return parts[1];&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public void setFullName(String name) {&#xA;&#x9;&#x9;this.fullName = name;&#xA;&#x9;}&#xA;&#xA;&#x9;@Override&#xA;&#x9;public String getFullName() {&#xA;&#x9;&#x9;return this.fullName" edit="/1/@proposals.1/@proposals.1/@attempts.19/@edit" start="206" end="-8"/>
        </attempts>
      </proposals>
      <proposals xsi:type="jdt:JdtLaunchProposal" question="/0/@parts.1/@tasks.2/@q" answer="/0/@parts.1/@tasks.2/@a">
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519297575699" mode="run" className="interfaces.Person1">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person1</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Sanderedee
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519297582531" mode="run" className="interfaces.Person1">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person1</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Lindbergedee
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519297594038" mode="run" className="interfaces.Person1">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person1</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>ff3Lindberg
</consoleOutput>
        </attempts>
      </proposals>
      <proposals xsi:type="jdt:JdtLaunchProposal" question="/0/@parts.1/@tasks.3/@q" answer="/0/@parts.1/@tasks.3/@a">
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519295413451" mode="run" className="interfaces.Person2">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person2</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Given name: null
Family name: null
Full name: Sander Lindberg
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519295440387" mode="run" className="interfaces.Person2">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person2</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Given name: Sander
Family name: Lindberg
Full name: Sander Lindberg
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519295892423" mode="run" className="interfaces.Person2">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person2</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.NullPointerException
	at interfaces.Person2.&lt;init>(Person2.java:6)
	at interfaces.Person2.main(Person2.java:52)
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519296069418" mode="run" className="interfaces.Person2">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person2</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Exception in thread &quot;main&quot; java.lang.NullPointerException
	at interfaces.Person2.setFullName(Person2.java:42)
	at interfaces.Person2.&lt;init>(Person2.java:8)
	at interfaces.Person2.main(Person2.java:57)
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519296096148" mode="run" className="interfaces.Person2">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.Person2</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>interfaces.Person2@75828a0f
</consoleOutput>
        </attempts>
      </proposals>
      <proposals xsi:type="junit:JunitTestProposal" question="/0/@parts.1/@tasks.4/@q" answer="/0/@parts.1/@tasks.4/@a">
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519294968482" completion="0.0" testRunName="interfaces.Person1Test" failureCount="1">
          <failureTests>testPerson1</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519295589314" completion="0.0" testRunName="interfaces.Person1Test" failureCount="1">
          <failureTests>testPerson1</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519296478146" completion="0.0" testRunName="interfaces.Person1Test" failureCount="1">
          <failureTests>testPerson1</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519298300189" completion="0.0" testRunName="interfaces.Person1Test" failureCount="1">
          <failureTests>testPerson1</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519298470306" completion="1.0" testRunName="interfaces.Person1Test" successCount="1">
          <successTests>testPerson1</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519298509698" completion="1.0" testRunName="interfaces.Person1Test" successCount="1">
          <successTests>testPerson1</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519816558276" completion="1.0" testRunName="interfaces.Person1Test" successCount="1">
          <successTests>testPerson1</successTests>
        </attempts>
      </proposals>
      <proposals xsi:type="junit:JunitTestProposal" question="/0/@parts.1/@tasks.5/@q" answer="/0/@parts.1/@tasks.5/@a">
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519294975979" completion="0.0" testRunName="interfaces.Person2Test" failureCount="1">
          <failureTests>testPerson2</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519295308292" completion="0.0" testRunName="interfaces.Person2Test" failureCount="1">
          <failureTests>testPerson2</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519295448003" completion="0.0" testRunName="interfaces.Person2Test" failureCount="1">
          <failureTests>testPerson2</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519295724031" completion="1.0" testRunName="interfaces.Person2Test" successCount="1">
          <successTests>testPerson2</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519296044891" completion="0.0" testRunName="interfaces.Person2Test" errorCount="1">
          <errorTests>testPerson2</errorTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519296102424" completion="0.0" testRunName="interfaces.Person2Test" failureCount="1">
          <failureTests>testPerson2</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519296181150" completion="0.0" testRunName="interfaces.Person2Test" failureCount="1">
          <failureTests>testPerson2</failureTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519296381659" completion="1.0" testRunName="interfaces.Person2Test" successCount="1">
          <successTests>testPerson2</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519298291623" completion="1.0" testRunName="interfaces.Person2Test" successCount="1">
          <successTests>testPerson2</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519816562567" completion="1.0" testRunName="interfaces.Person2Test" successCount="1">
          <successTests>testPerson2</successTests>
        </attempts>
      </proposals>
    </proposals>
    <proposals exercisePart="/0/@parts.2">
      <proposals xsi:type="jdt:JdtSourceEditProposal" question="/0/@parts.2/@tasks.0/@q" answer="/0/@parts.2/@tasks.0/@a">
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295020557" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="7" errorCount="2" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:StringEdit" storedString="package interfaces;&#xA;&#xA;import java.util.Comparator;&#xA;&#xA;public class NamedComparator implements Comparator&lt;T> {&#xA;&#xA;}&#xA;"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="5" charStart="102" charEnd="103" severity="2" problemCategory="40" problemType="16777218"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519295306949" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="13" errorCount="4" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;@Override&#xA;&#x9;public int compare(T arg0, T arg1) {&#xA;&#x9;&#x9;// TODO Auto-generated method stub&#xA;&#x9;&#x9;return 0;&#xA;&#x9;}" edit="/1/@proposals.2/@proposals.0/@attempts.0/@edit" start="108" end="-5"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="8" charStart="147" charEnd="148" severity="2" problemCategory="40" problemType="16777218"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519298794818" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="16" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="Named> {&#xA;&#xA;&#x9;@Override&#xA;&#x9;public int compare(Named named1, Named named2) {&#xA;&#x9;&#x9;if(named1.getFamilyName().compareTo(named2.getFamilyName()) == 0) {&#xA;&#x9;&#x9;&#x9;return named1.getGivenName().compareTo(named2.getGivenName());&#xA;&#x9;&#x9;}else {&#xA;&#x9;&#x9;&#x9;return named1.getFamilyName().compareTo(named2.getFamilyName());&#xA;&#x9;&#x9;}" edit="/1/@proposals.2/@proposals.0/@attempts.1/@edit" start="102" end="-8"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519298918469" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="20" warningCount="1" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="ArrayList;&#xA;import java.util.Comparator;&#xA;import java.util.List;&#xA;&#xA;public class NamedComparator implements Comparator&lt;Named> {&#xA;&#xA;&#x9;@Override&#xA;&#x9;public int compare(Named named1, Named named2) {&#xA;&#x9;&#x9;if(named1.getFamilyName().compareTo(named2.getFamilyName()) == 0) {&#xA;&#x9;&#x9;&#x9;return named1.getGivenName().compareTo(named2.getGivenName());&#xA;&#x9;&#x9;}else {&#xA;&#x9;&#x9;&#x9;return named1.getFamilyName().compareTo(named2.getFamilyName());&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;List&lt;Named> liste = new ArrayList&lt;Named>();&#xA;&#x9;}" edit="/1/@proposals.2/@proposals.0/@attempts.2/@edit" start="38" end="-4"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="18" charStart="501" charEnd="506" severity="1" problemCategory="120" problemType="536870973"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519298974941" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="23" warningCount="3" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="&#x9;Person1 p1 = new Person1(&quot;Sander&quot;, &quot;Lindberg&quot;);&#xA;&#x9;&#x9;Person2 p2 = new Person2(&quot;Marcus Henriksbø&quot;);&#xA;&#x9;&#x9;" edit="/1/@proposals.2/@proposals.0/@attempts.3/@edit" start="534" end="-7"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="20" charStart="593" charEnd="595" severity="1" problemCategory="120" problemType="536870973"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519299129044" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="30" errorCount="2" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="llections;&#xA;import java.util.Comparator;&#xA;import java.util.List;&#xA;&#xA;public class NamedComparator implements Comparator&lt;Named> {&#xA;&#xA;&#x9;@Override&#xA;&#x9;public int compare(Named named1, Named named2) {&#xA;&#x9;&#x9;if(named1.getFamilyName().compareTo(named2.getFamilyName()) == 0) {&#xA;&#x9;&#x9;&#x9;return named1.getGivenName().compareTo(named2.getGivenName());&#xA;&#x9;&#x9;}else {&#xA;&#x9;&#x9;&#x9;return named1.getFamilyName().compareTo(named2.getFamilyName());&#xA;&#x9;&#x9;}&#xA;&#x9;}&#xA;&#x9;public static void main(String[] args) {&#xA;&#x9;&#x9;List&lt;Named> liste = new ArrayList&lt;Named>();&#xA;&#x9;&#x9;Person1 p1 = new Person1(&quot;Sander&quot;, &quot;Lindberg&quot;);&#xA;&#x9;&#x9;Person2 p2 = new Person2(&quot;Marcus Henriksbø&quot;);&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;liste.add(p2);&#xA;&#x9;&#x9;liste.add(p1);&#xA;&#x9;&#x9;&#xA;&#x9;&#x9;NamedComparator o = new NamedComparator();&#xA;&#x9;&#x9;System.out.println(&quot;Original: &quot; + liste);&#xA;&#x9;&#x9;System.out.println(&quot;Collections: &quot; + Collections.sort(liste, o);" edit="/1/@proposals.2/@proposals.0/@attempts.4/@edit" start="68" end="-7"/>
          <markers xsi:type="jdt:JdtMarkerInfo" lineNumber="28" charStart="854" charEnd="855" severity="2" problemCategory="20" problemType="1610612976"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519299195007" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="30" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="System.out.println(&quot;Original: &quot; + liste);&#xA;&#x9;&#x9;Collections.sort(liste, new NamedComparator());&#xA;&#x9;&#x9;System.out.println(&quot;Collections: &quot; + liste" edit="/1/@proposals.2/@proposals.0/@attempts.5/@edit" start="703" end="-9"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519299207176" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="30" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="1);&#xA;&#x9;&#x9;liste.add(p2" edit="/1/@proposals.2/@proposals.0/@attempts.6/@edit" start="677" end="-153"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519299418379" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="32" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="System.out.println(&quot;P1: &quot; + p1 + &quot; &quot; + p1.getGivenName());&#xA;&#x9;&#x9;System.out.println(&quot;P2: &quot; + p2 + &quot; &quot; + p2.getGivenName());" edit="/1/@proposals.2/@proposals.0/@attempts.7/@edit" start="666" end="-185"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519299428539" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="32" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="Sander" edit="/1/@proposals.2/@proposals.0/@attempts.8/@edit" start="641" end="-323"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519299439377" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="32" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="M" edit="/1/@proposals.2/@proposals.0/@attempts.9/@edit" start="648" end="-321"/>
        </attempts>
        <attempts xsi:type="jdt:JdtSourceEditEvent" timestamp="1519299452827" resourcePath="/ovinger/src/interfaces/NamedComparator.java" sizeMeasure="32" className="interfaces.NamedComparator">
          <edit xsi:type="exercise:ReplaceSubstringEdit" storedString="Marcus H" edit="/1/@proposals.2/@proposals.0/@attempts.10/@edit" start="641" end="-321"/>
        </attempts>
      </proposals>
      <proposals xsi:type="jdt:JdtLaunchProposal" question="/0/@parts.2/@tasks.1/@q" answer="/0/@parts.2/@tasks.1/@a">
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299196525" mode="run" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Original: [interfaces.Person2@6d86b085, interfaces.Person1@75828a0f]
Collections: [interfaces.Person2@6d86b085, interfaces.Person1@75828a0f]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299208780" mode="run" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>Original: [interfaces.Person1@6d86b085, interfaces.Person2@75828a0f]
Collections: [interfaces.Person2@75828a0f, interfaces.Person1@6d86b085]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299419690" mode="run" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@6d86b085 Sander
P2: interfaces.Person2@75828a0f Marcus
Original: [interfaces.Person1@6d86b085, interfaces.Person2@75828a0f]
Collections: [interfaces.Person2@75828a0f, interfaces.Person1@6d86b085]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299430843" mode="run" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@6d86b085 Sander
P2: interfaces.Person2@75828a0f Sander
Original: [interfaces.Person1@6d86b085, interfaces.Person2@75828a0f]
Collections: [interfaces.Person2@75828a0f, interfaces.Person1@6d86b085]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299440517" mode="run" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@6d86b085 Sander
P2: interfaces.Person2@75828a0f Sander
Original: [interfaces.Person1@6d86b085, interfaces.Person2@75828a0f]
Collections: [interfaces.Person1@6d86b085, interfaces.Person2@75828a0f]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299666380" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299671030" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299679882" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299690079" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299722798" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299736740" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299742881" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299744465" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
        <attempts xsi:type="jdt:JdtLaunchEvent" timestamp="1519299869856" mode="debug" className="interfaces.NamedComparator">
          <launchAttrNames>org.eclipse.jdt.launching.MAIN_TYPE</launchAttrNames>
          <launchAttrNames>org.eclipse.jdt.launching.PROJECT_ATTR</launchAttrNames>
          <launchAttrValues>interfaces.NamedComparator</launchAttrValues>
          <launchAttrValues>ovinger</launchAttrValues>
          <consoleOutput>P1: interfaces.Person1@42f30e0a Sander
P2: interfaces.Person2@24273305 Marcus
Original: [interfaces.Person1@42f30e0a, interfaces.Person2@24273305]
Collections: [interfaces.Person2@24273305, interfaces.Person1@42f30e0a]
</consoleOutput>
        </attempts>
      </proposals>
      <proposals xsi:type="junit:JunitTestProposal" question="/0/@parts.2/@tasks.2/@q" answer="/0/@parts.2/@tasks.2/@a">
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519298802391" completion="1.0" testRunName="interfaces.NamedComparatorTest" successCount="1">
          <successTests>testNamedComparator</successTests>
        </attempts>
        <attempts xsi:type="junit:JunitTestEvent" timestamp="1519816553772" completion="1.0" testRunName="interfaces.NamedComparatorTest" successCount="1">
          <successTests>testNamedComparator</successTests>
        </attempts>
      </proposals>
    </proposals>
    <proposals exercisePart="/0/@parts.3">
      <proposals xsi:type="workbench:DebugEventProposal" question="/0/@parts.3/@tasks.0/@q" answer="/0/@parts.3/@tasks.0/@a"/>
      <proposals xsi:type="workbench:DebugEventProposal" question="/0/@parts.3/@tasks.1/@q" answer="/0/@parts.3/@tasks.1/@a"/>
      <proposals xsi:type="workbench:CommandExecutionProposal" question="/0/@parts.3/@tasks.2/@q" answer="/0/@parts.3/@tasks.2/@a">
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788925808" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788926885" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788928977" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788930755" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788936431" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788955720" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788956244" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788956728" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788960114" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788962303" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788963023" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788963796" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788965240" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788969140" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788970428" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788990929" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788992369" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788993509" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788995503" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789003111" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789009507" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789016825" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789017347" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789017819" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789020271" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789103304" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789103540" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789103757" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789104102" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789104313" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789104873" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789105342" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789105730" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789106236" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789111084" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789112697" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789113276" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789113830" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789114416" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789137277" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789141757" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789143149" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789144219" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789148513" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789150934" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789156779" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789157236" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789157692" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789158143" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789158611" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789159072" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789162559" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789163744" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789164954" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789165562" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789166318" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789169962" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789190899" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789293319" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789293491" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789293690" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789293979" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789294144" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789294492" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789300877" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789301190" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789301471" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789301843" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789302305" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789306427" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789306950" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789307419" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789307943" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789308629" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789320206" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789323518" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789325331" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789325970" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789326486" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789327032" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789372974" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789373318" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789373553" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789373733" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789374376" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789375998" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789376356" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789376549" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789377354" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789378040" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789382342" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789387915" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789388812" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789389262" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789389576" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789389866" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789391211" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789391951" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789426589" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789624397" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789624904" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789859204" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789859782" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789860203" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789860594" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789861016" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789863846" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789864262" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789868712" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789869596" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789870338" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789889018" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789890607" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789891753" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789893849" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789894777" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789896905" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789902353" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789903593" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791532338" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791545539" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791546001" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791546515" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791550748" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791551099" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791551466" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791551871" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791552292" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791595056" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791617995" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791656857" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791660315" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791660719" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791661551" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791663075" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791663403" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791663815" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791664173" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791664559" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791670155" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791671451" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791682949" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791684568" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791781552" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791783554" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791783762" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791784238" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791785582" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791785924" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791786475" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791786960" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791787434" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791790517" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791798789" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791802055" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791821183" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791907966" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791910332" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791910550" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791911000" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791912710" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791912915" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791913120" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791913424" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791913874" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791917622" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791919221" elementId="org.eclipse.debug.ui.commands.StepOver" action="executeSuccess"/>
      </proposals>
      <proposals xsi:type="workbench:CommandExecutionProposal" question="/0/@parts.3/@tasks.3/@q" answer="/0/@parts.3/@tasks.3/@a">
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788937807" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788953015" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518788971366" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789107712" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789116188" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789153964" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789161012" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789167878" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789304057" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789312732" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789316949" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789375116" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789379076" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789380838" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789399862" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789430963" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789861962" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789871622" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518789876544" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791534536" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791548627" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791553789" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791658736" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791662421" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791665805" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791673213" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791782830" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791784960" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791788506" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791800469" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791803618" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791909744" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791911878" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
        <attempts xsi:type="workbench:WorkbenchTaskEvent" timestamp="1518791914916" elementId="org.eclipse.debug.ui.commands.StepInto" action="executeSuccess"/>
      </proposals>
      <proposals xsi:type="workbench:PartTaskProposal" question="/0/@parts.3/@tasks.4/@q" answer="/0/@parts.3/@tasks.4/@a">
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518788940564" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518789120438" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518789330165" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518789383864" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518789872849" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518791558472" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518791667714" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
        <attempts xsi:type="workbench:PartTaskEvent" timestamp="1518791796533" elementId="org.eclipse.debug.ui.VariableView" action="activated"/>
      </proposals>
    </proposals>
  </exercise:ExerciseProposals>
</xmi:XMI>
