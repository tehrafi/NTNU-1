def to():
    return print(2)


to()