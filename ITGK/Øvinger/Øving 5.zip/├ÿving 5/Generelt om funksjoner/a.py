def xy(x, y):
    return print(str(x) + " * " + str(y) + " = " + str(x*y))


x = int(input("Skriv inn et tall x: "))
y = int(input("Skriv inn et tall y: "))

xy(x, y)