def arg(argument):
    return print(argument)


argument = input("Skriv inn et argument: ")
arg(argument)