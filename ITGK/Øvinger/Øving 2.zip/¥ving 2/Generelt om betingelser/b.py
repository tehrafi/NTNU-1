svar = int(input("Hva er 3*4? "))

if svar == 12:
    print("Korrekt!")
else:
    print(svar,"er feil!")
