

#Git pull repository


#Git set library
We are using intellij IDEA, where we have to
File -> Project Structure -> Libraries -> + -> java -> treningsapp/lib



treningsapp
