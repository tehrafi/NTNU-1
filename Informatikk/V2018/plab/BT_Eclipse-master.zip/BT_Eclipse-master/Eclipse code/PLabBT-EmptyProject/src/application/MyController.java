package application;
import javafx.fxml.FXML;

public class MyController {
	
	@FXML
	void initialize() {		
	}
	
}
