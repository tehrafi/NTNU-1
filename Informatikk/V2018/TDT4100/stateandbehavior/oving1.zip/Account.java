package stateandbehavior;

public class Account {
	double balance = 0;
	double interestRate = 0;
	
	void deposit(double in) {
		if(in >= 0) {
			balance = balance + in;
		}else{
			System.out.println("Du m� legge inn en positiv sum");
		}
	}
	
	void setInterestRate(double rate) {
		interestRate = rate;
	}
	
	double getInterestRate() {
		return interestRate;
	}
	
	double getBalance() {
		return balance;
	}
	
	void addInterest() {
		balance = balance + (balance*(interestRate/100));
	}
	
	@Override
	public String toString() {
		String str = "Kontoen har " + getBalance() + " kroner disponibelt. Renten er for �yeblikket " + getInterestRate();
		return str;
	}
	
	public static void main(String[] args) {
		Account ac = new Account();
		ac.setInterestRate(5);
		ac.deposit(100);
		ac.addInterest();
		System.out.println(ac.getBalance());
		System.out.println(ac.getInterestRate());
		System.out.println(ac.toString());
	}
}
