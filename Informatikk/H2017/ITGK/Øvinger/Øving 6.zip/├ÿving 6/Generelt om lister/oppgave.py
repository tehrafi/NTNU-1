my_first_list = [1, 2, 3, 4, 5, 6]

print(my_first_list[-1])

my_first_list[4] = "+"

my_second_list = my_first_list[3::]

print(my_second_list, " er lik 10")
