x = 0
for i in range(0, 101):
    x = x + i

print("Summen av de 100 første tallene er",x)