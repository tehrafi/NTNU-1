i = 0

while i < 1:
    svar = int(input("Hva er 3*4? "))
    if(svar == 12):
        print("Stemmer, svaret er 12!")
        i = 2
    else:
        i = 0
