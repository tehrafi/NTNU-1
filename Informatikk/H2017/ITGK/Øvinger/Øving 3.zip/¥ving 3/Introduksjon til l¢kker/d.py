i = 15
while i > 0:
    print(i)
    i = i-1
