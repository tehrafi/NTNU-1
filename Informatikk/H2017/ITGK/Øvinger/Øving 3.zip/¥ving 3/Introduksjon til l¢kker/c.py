for i in range(15 ,0, -1):
    print(i)


