from turtle import *


for i in range(16, 0, -3): #Starter i 16, slutter i 0, går nedover med 3
   pensize(i) #Tykkelsen på pennen endres
   forward(50)

done()