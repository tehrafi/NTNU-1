mittNavn = "Sander"
minAlder = 19
print("Mitt navn er " + mittNavn + ", og jeg er",minAlder,"år gammel")
