mittNavn = "Sander"
print("Mitt navn er",mittNavn)
