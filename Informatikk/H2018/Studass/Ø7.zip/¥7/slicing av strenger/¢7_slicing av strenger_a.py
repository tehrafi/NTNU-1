
def sliStr(string):
    return string[0:len(string):4]


x = str(input('Oppgi streng: '))
print(sliStr(x))
